package dijsktra;

import grafo.Grafo;

public class Dijsktra {

	private Grafo g;

	public Dijsktra(Grafo g) {
		this.g = g;
	}

	public int[] resolver(int nodoIni, boolean prec) {
		int cantNodos = g.getCantNodos();
		boolean[] nodosVisitados = new boolean[cantNodos];
		int[] d = new int[cantNodos];
		int[] p = new int[cantNodos];
		for (int i = 0; i < cantNodos; i++) {
			d[i] = g.getDistNodo(nodoIni, i);
			p[i] = nodoIni; // Inicializo la precedencia hacia todos los nodos con el inicial
		}

		int w = nodoIni;
		int dwi, di, dw;

		for (int j = 0; j < cantNodos - 1; j++) {
			nodosVisitados[w] = true;
			dw = d[w];
			for (int i = 0; i < cantNodos; i++) {

				if (!nodosVisitados[i]) {
					di = d[i];
					dwi = g.getDistNodo(w, i);

					if (di == 0 && dw != 0 && dwi != 0) {
						// d[i] es infinito
						d[i] = dw + dwi;
						p[i] = w;
					} else if (dw != 0 && dwi != 0) {
						// d[w] y C[w,i] y d[i] no es infinito
						if (di > dw + dwi) {
							d[i] = dw + dwi;
							p[i] = w;
						}
					}
				}
			}
			w = buscarW(d, nodosVisitados);
		}

		if (prec) {
			return p;
		}
		return d;
	}

	private int buscarW(int[] dAux, boolean[] nodosVisitados) {
		int min = -1, w = 0;

		for (int i = 0; i < dAux.length; i++) {

			if (!nodosVisitados[i]) {
				if (min == -1) {
					min = dAux[i];
					w = i;
				}
				if (min != 0 && dAux[i] != 0 && min > dAux[i]) {
					min = dAux[i];
					w = i;
				} else if (min == 0 && dAux[i] != 0) {
					min = dAux[i];
					w = i;

				}
			}
		}

		return w;
	}

	public String obtenerCaminoMinimo(int[] prec, int nodoI, int nodoF) {
		String aux = "" + nodoF;
		while (prec[nodoF] != nodoI) {
			if (!aux.equals("") && aux != null) {
				aux = " -> " + aux;
			}
			aux = prec[nodoF] + "" + aux;
			nodoF = prec[nodoF];
		}
		return nodoI + " -> " + aux;
	}

	public static void main(String[] args) {
		Grafo g = new Grafo(7);
		g.agregarPeso(0, 3, 3);
		g.agregarPeso(0, 2, 2);
		g.agregarPeso(0, 4, 1);

		g.agregarPeso(1, 2, 10);
		g.agregarPeso(1, 3, 1);

		g.agregarPeso(3, 0, 3);
		g.agregarPeso(3, 1, 1);
		g.agregarPeso(3, 4, 5);
		g.agregarPeso(3, 5, 20);

		g.agregarPeso(2, 0, 2);
		g.agregarPeso(2, 1, 10);

		g.agregarPeso(4, 5, 30);
		g.agregarPeso(4, 3, 5);
		g.agregarPeso(4, 0, 1);
		g.agregarPeso(4, 6, 21);

		g.agregarPeso(5, 3, 20);
		g.agregarPeso(5, 4, 30);
		g.agregarPeso(5, 6, 1);

		g.agregarPeso(6, 4, 21);
		g.agregarPeso(6, 5, 1);

		Dijsktra d = new Dijsktra(g);
		boolean precedencia = false;
		int[] p = d.resolver(6, precedencia);
		System.out.println(p[0] + "-" + p[1] + "-" + p[2] + "-" + p[3] + "-" + p[4] + "-" + p[5]);
//		String caminosMin = d.obtenerCaminoMinimo(p, 6, 1);
//		System.out.println(caminosMin);

	}

}
