package grafo;

public class Grafo {

	int cantNodos;
	int[][] ady;

	public Grafo(int can) {
		this.cantNodos = can;
		this.ady = new int[can][can];
	}

	public void agregarPeso(int nodoIni, int nodoFin, int peso) {
		this.ady[nodoIni][nodoFin] = peso;
	}

	public int getCantNodos() {
		// TODO Auto-generated method stub
		return this.cantNodos;
	}

	public int getDistNodo(int i, int j) {
		return this.ady[i][j];
	}

}
