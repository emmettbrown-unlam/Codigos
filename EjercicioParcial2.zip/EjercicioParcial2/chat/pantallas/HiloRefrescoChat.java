package pantallas;

import javax.swing.JTextArea;

import cliente.Cliente;
import msg.MsgObtenerChatActual;

public class HiloRefrescoChat extends Thread {

	private Cliente cliente;
	private JTextArea area;

	public HiloRefrescoChat(Cliente cliente, JTextArea area) {
		this.cliente = cliente;
		this.area = area;
	}

	@Override
	public void run() {
		while (true) {
			this.cliente.enviarMsg(new MsgObtenerChatActual());
			area.setText((String) this.cliente.recibirMsg());
		}
	}
}
