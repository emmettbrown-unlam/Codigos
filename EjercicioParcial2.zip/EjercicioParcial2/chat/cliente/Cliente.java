package cliente;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;

import msg.Msg;

public class Cliente implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String host;
	private String mensajeError = null;
	private ObjectInputStream reciboMsg;
	private Socket client;
	private ObjectOutputStream outPutStream;

	public Socket obtenerSocketCliente() {
		return client;
	}

	public Cliente(String ip, int puerto) {
		try {
			this.host = ip;
			this.client = new Socket(host, puerto);

		} catch (UnknownHostException e) {
			this.mensajeError = "No se encontro ningun servidor al cual conectarse!";
			System.out.println(mensajeError);
		} catch (IOException e) {
			this.mensajeError = "No se encontro ningun servidor al cual conectarse!";
			System.out.println(mensajeError);
		}
	}

	public String obtenerMsgErr() {
		return mensajeError;
	}

	public synchronized void enviarMsg(Msg consultaAlServidor) {
		try {
			this.outPutStream = new ObjectOutputStream(client.getOutputStream());
			outPutStream.writeObject(consultaAlServidor);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Error al querer enviar peticion al sv " + e);

		}

	}

	public synchronized Object recibirMsg() {
		Object obj = "";
		try {
			reciboMsg = new ObjectInputStream(client.getInputStream());
			obj = reciboMsg.readObject();
		} catch (IOException | ClassNotFoundException e) {
			this.mensajeError = "Comunicacion cerrada en recibir msg1. " + e;
			System.out.println(mensajeError);
		}
		return obj;
	}

	public void cerrarComunicacion() {

		try {
			reciboMsg.close();
			outPutStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(mensajeError);
			this.mensajeError = "problemas al cerrar comunicacion. " + e;
		}
	}

}
