package msg;

import javax.swing.JTextArea;

public class MsgObtenerChatActual extends Msg {

	private static final long serialVersionUID = 1L;

	@Override
	public String realizarAccion(Object obj1, Object obj2, Object obj3) {
		JTextArea area = (JTextArea) obj1;
		return area.getText();
	}

}
