package msg;

import javax.swing.JTextArea;

public class MsgEnviarMensaje extends Msg {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String usuario;
	private String mensaje;

	public MsgEnviarMensaje(String mensaje, String usuario) {
		this.usuario = usuario;
		this.mensaje = mensaje;
	}

	@Override
	public String realizarAccion(Object obj1, Object obj2, Object obj3) {
		JTextArea textArea = (JTextArea) obj1;
		textArea.append(this.usuario + " dice: " + mensaje + "\n");
		return textArea.getText();
	}

}
