package msg;

import java.util.ArrayList;

import cliente.Cliente;

public class MsgLogin extends Msg {
	private String usuario;
	private String clave;
	private Cliente cliente;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MsgLogin(String usuario, String contrasena, Cliente cliente) {
		this.usuario = usuario;
		this.cliente = cliente;
		this.clave = contrasena;
	}

	@Override
	public String realizarAccion(Object obj1, Object obj2, Object obj3) {
		// TODO Auto-generated method stub
		if ((this.usuario.equals("Usuario") && this.clave.equals("clave"))
				|| (this.usuario.equals("Usuario2") && this.clave.equals("clave2"))) {
			ArrayList<Cliente> usuariosConectados = (ArrayList<Cliente>) obj2;
			usuariosConectados.add(cliente);
			return "OK";
		}
		return "FAIL";
	}

}
