package servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JTextArea;

import cliente.Cliente;

public class Servidor {

	private int PORT;
	private static ServerSocket serverSocket;
	private static ArrayList<Cliente> usuariosConectados;
	private static JTextArea chat; // Tenemos un unico Caja de texto en el servidor. ahi va estar todas las
									// mensajes

	public Servidor(int puerto) {
		this.PORT = puerto;
		this.usuariosConectados = new ArrayList<>();
		this.chat = new JTextArea();
	}

	public static void main(String[] args) {
		Servidor sv = new Servidor(5000);
		try {
			serverSocket = new ServerSocket(sv.obtenerPuerto());
			// Socket of the client
			Socket clientSocket;
			while (true) {
				System.out.println("Servidor esperando clientes!");
				clientSocket = serverSocket.accept();
				System.out.println("conexion aceptada!");
				HiloCliente hiloCliente = new HiloCliente(clientSocket, usuariosConectados, chat);
				hiloCliente.start();

			}
		} catch (IOException ex) {
			System.out.println(ex);
		}
	}

	private int obtenerPuerto() {
		// TODO Auto-generated method stub
		return this.PORT;
	}

}
