package servidor;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JTextArea;

import cliente.Cliente;
import msg.Msg;

public class HiloCliente extends Thread {

	private Socket cliente;
	private boolean estaConectado;
	private ArrayList<Cliente> usuariosConectados = new ArrayList<>();
	private JTextArea chat;

	public HiloCliente(Socket cliente, ArrayList<Cliente> usuariosConectados, JTextArea c) {
		this.cliente = cliente;
		this.usuariosConectados = usuariosConectados;
		this.estaConectado = true;
		this.chat = c;
	}

	@Override
	public void run() {

		try {
			ObjectInputStream reciboMsg = null;
			ObjectOutputStream salidaACliente = null;

			while (estaConectado) {

				/* Recibo Consulta de cliente */
				reciboMsg = new ObjectInputStream(cliente.getInputStream());
				Msg msgRecibo = (Msg) reciboMsg.readObject();
				Object resultado = msgRecibo.realizarAccion(this.chat, this.usuariosConectados, null);
				/* Envio respuesta al Cliente */
				salidaACliente = new ObjectOutputStream(cliente.getOutputStream());
				salidaACliente.writeObject(resultado); // Se debe cerrar

			}

			reciboMsg.close();
			salidaACliente.close();
			cliente.close();
		} catch (IOException | ClassNotFoundException ex) {
			System.out.println("Problemas al querer leer otra petici�n: " + ex.getMessage());
		}

	}

}
